import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { User, Briefcase, Phone, Mail, Globe, Linkedin, Download, Share2 } from 'lucide-react';

function App() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    title: '',
    company: '',
    phone: '',
    email: '',
    website: '',
    linkedin: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const generateVCard = () => {
    const vcard = `BEGIN:VCARD\nVERSION:3.0\nN:${formData.lastName};${formData.firstName};;;\nFN:${formData.firstName} ${formData.lastName}\nORG:${formData.company}\nTITLE:${formData.title}\nTEL;TYPE=WORK,VOICE:${formData.phone}\nEMAIL;TYPE=PREF,INTERNET:${formData.email}\nURL:${formData.website}\nX-SOCIALPROFILE;type=linkedin:${formData.linkedin}\nEND:VCARD`;
    return vcard;
  };

  const handleDownloadVCard = () => {
    const element = document.createElement("a");
    const file = new Blob([generateVCard()], {type: 'text/vcard'});
    element.href = URL.createObjectURL(file);
    element.download = `${formData.firstName || 'Contact'}_${formData.lastName || 'Info'}.vcf`;
    document.body.appendChild(element); // Required for this to work in FireFox
    element.click();
    document.body.removeChild(element);
  };

  const vcardData = generateVCard();

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold text-gray-900 tracking-tight sm:text-5xl">
            Dijital Kartvizit (Q Card)
          </h1>
          <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
            Bilgilerinizi girin, QR kodunuzu oluşturun ve anında paylaşın. App-preneur ödev projesi.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden md:flex">
          {/* Form Section */}
          <div className="p-8 md:w-1/2 space-y-6 bg-white">
            <h2 className="text-2xl font-bold text-gray-800 border-b pb-2">Kişisel Bilgiler</h2>
            
            <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Ad</label>
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-4 w-4 text-gray-400" />
                  </div>
                  <input type="text" name="firstName" value={formData.firstName} onChange={handleChange} className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md py-2 border outline-none transition-colors" placeholder="Ahmet" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Soyad</label>
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-4 w-4 text-gray-400" />
                  </div>
                  <input type="text" name="lastName" value={formData.lastName} onChange={handleChange} className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md py-2 border outline-none transition-colors" placeholder="Yılmaz" />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Ünvan / Pozisyon</label>
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Briefcase className="h-4 w-4 text-gray-400" />
                  </div>
                  <input type="text" name="title" value={formData.title} onChange={handleChange} className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md py-2 border outline-none transition-colors" placeholder="Yazılım Geliştirici" />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Şirket</label>
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Briefcase className="h-4 w-4 text-gray-400" />
                  </div>
                  <input type="text" name="company" value={formData.company} onChange={handleChange} className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md py-2 border outline-none transition-colors" placeholder="Tech A.Ş." />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Telefon</label>
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Phone className="h-4 w-4 text-gray-400" />
                  </div>
                  <input type="tel" name="phone" value={formData.phone} onChange={handleChange} className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md py-2 border outline-none transition-colors" placeholder="+90 555 123 4567" />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">E-posta</label>
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-4 w-4 text-gray-400" />
                  </div>
                  <input type="email" name="email" value={formData.email} onChange={handleChange} className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md py-2 border outline-none transition-colors" placeholder="ahmet@example.com" />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Web Sitesi</label>
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Globe className="h-4 w-4 text-gray-400" />
                  </div>
                  <input type="url" name="website" value={formData.website} onChange={handleChange} className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md py-2 border outline-none transition-colors" placeholder="https://www.example.com" />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">LinkedIn URL</label>
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Linkedin className="h-4 w-4 text-gray-400" />
                  </div>
                  <input type="url" name="linkedin" value={formData.linkedin} onChange={handleChange} className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md py-2 border outline-none transition-colors" placeholder="https://linkedin.com/in/username" />
                </div>
              </div>
            </div>
          </div>

          {/* Preview & QR Section */}
          <div className="p-8 md:w-1/2 bg-indigo-50 flex flex-col items-center justify-center space-y-8 border-l border-indigo-100">
            <div className="w-full max-w-sm bg-white rounded-xl shadow-lg p-6 border border-gray-100 text-center relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-500 to-purple-500"></div>
              <h3 className="text-2xl font-bold text-gray-900 mt-2">
                {formData.firstName || formData.lastName ? `${formData.firstName} ${formData.lastName}` : "Ad Soyad"}
              </h3>
              <p className="text-md text-indigo-600 font-medium mt-1">{formData.title || "Ünvan"}</p>
              <p className="text-sm text-gray-500 mb-6 mt-1">{formData.company || "Şirket"}</p>
              
              <div className="flex justify-center bg-white p-4 rounded-xl shadow-sm border border-gray-100 mb-6 mx-auto w-max">
                <QRCodeSVG 
                  value={vcardData} 
                  size={200}
                  level={"H"}
                  includeMargin={true}
                />
              </div>
              
              <p className="text-xs text-gray-500 mb-6 px-4">
                Kişiyi telefon rehberinize eklemek için kameranızla QR kodu okutun.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 justify-center w-full">
                <button 
                  onClick={handleDownloadVCard}
                  className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
                >
                  <Download className="mr-2 h-4 w-4" /> VCF İndir
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;